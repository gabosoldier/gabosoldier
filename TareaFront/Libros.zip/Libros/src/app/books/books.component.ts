import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from '../services/book';
import { BookService } from '../services/book.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.scss']
})
export class BooksComponent implements OnInit {

  books: Book[] = [];
  selectedBook: Book = new Book;
  
  constructor(private router: Router, private bookService: BookService) {
 
  }
 
  ngOnInit() {
    this.bookService.getBooks().then(books => this.books = books);
  }
 
  showInfo(book: Book): void {
    this.selectedBook = book;
    this.router.navigate(['/information', this.selectedBook.bookId]);
  }

}
