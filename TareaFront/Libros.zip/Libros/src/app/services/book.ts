export class Book {
    bookId!: number;
    title!: String;
    authors!: String[];
    editorial!: String;
    short_description!: String;
}
