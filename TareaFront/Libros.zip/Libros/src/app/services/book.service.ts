import { Injectable } from '@angular/core';
import { Book } from './book';
import { BOOKS } from './book-store';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  getBook(id: number): Promise<Book> {

    return new Promise(async ( resolve, reject ) => {

      const book = await this.getBooks().then(books => books.find(book => book.bookId === id));

      (book) 
          ? resolve( book )
          : reject( `No existe libro con id ${ id }` );
    });
  }
  constructor() { }
 
  getBooks(): Promise<Book[]> {
    return Promise.resolve(BOOKS);
  }
}
